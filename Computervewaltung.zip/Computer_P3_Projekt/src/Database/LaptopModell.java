
package Database;

import java.util.UUID;


public class LaptopModell {
    
        public UUID id;	
	 public String marke ;
	 public int  speicherplatz;
	 public String prozessor;
	 public int arbeitsspeicher;
	 public float preis;
	 public String bild;
         public boolean gebraucht;
	 
		public LaptopModell(UUID id, String marke, int speicherplatz, String prozessor, int arbeitsspeicher, float preis, String bildSource,boolean gebraucht, String line)
		{
			this.id = id;
			this.marke = marke;
			this.speicherplatz= speicherplatz;
			this.prozessor= prozessor;
			this.arbeitsspeicher = arbeitsspeicher;
			this.preis= preis;
			this.bild = bildSource;
                        this.gebraucht = gebraucht;
			
			
			
		}
		
		
		

		public void getData()
		{   System.out.println(id);
			System.out.println(marke);
			System.out.println(speicherplatz);
			System.out.println(prozessor);
			System.out.println(arbeitsspeicher);
			System.out.println(preis);
			System.out.println(bild);
                        System.out.println(gebraucht);
                        
		
		}
    
}

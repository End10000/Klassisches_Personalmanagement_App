
package View;

import Controller.ListSeite;
import Controller.ListSeite2;
import Database.Datenbank;
import Database.LaptopModell;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;


public class NeueSuchen extends JPanel{
    
    JLabel marke = new JLabel("Marke");
 
    public JTextField textmarke = new JTextField();
    
    public String Mark ;
    
   
     JButton buttonsuche = new JButton();
   
    
    
    public JLabel titel = new JLabel("                                      SUCHEN");
    
    Datenbank datenbank = new Datenbank();
       String Marke;
     public  NeueSuchen () {

   setLayout(null);
    setBackground(Color.white);
    
    marke.setBounds(300,80,100,30);
     marke.setFont(new Font("Roboto",Font.BOLD,20));		
    textmarke.setBounds(370,75,200,40);
                
                
                buttonsuche.setBounds(570, 75,50, 40);
                buttonsuche.setToolTipText("Suchen....");
		
		buttonsuche.setIcon(new ImageIcon("icon/such.png"));
                
                
                
                
                buttonsuche.addActionListener((ActionEvent e) -> {
                    if (e.getSource() == buttonsuche){
                        
                        
              
                        //String Marke = (textmarke.getText().equals("Marke")) ? "" : textmarke.getText();
                        String Marke = textmarke.getText();
                        
                        //boolean isAvailable = view.availableBox.isSelected();
                        //get Data
                        List<LaptopModell> data = new ArrayList<>();
                        data = datenbank.findData2(null,Marke);
                        
                        showData(data);
                        
                        
                        
                    }
                
    });
                
                
               add(marke);
               add(textmarke);
              add(buttonsuche);
               
                
                
             
}
     
     public  void showData(List<LaptopModell> data)
	{	
		//delete previous scrollPane
		Component[] componentList = this.getComponents();
		for(Component c : componentList) {
			if(c instanceof JScrollPane) {
				this.remove(c);
			}
		}
		//refresh gui
		this.revalidate();
		this.repaint();
		
		//create new scrollPane for the results
		JPanel resultPanel = new JPanel();
		resultPanel.setLayout(new BoxLayout(resultPanel, BoxLayout.PAGE_AXIS));
		
		//add scroll properties
		JScrollPane resultList = new JScrollPane(resultPanel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		resultList.setBounds(270,200,400,400);
		
		
		//create result cards
		for(int i=0;i<data.size();i++)
		{
			//resultViews
			resultPanel.add(new ListSeite2(data.get(i).id,data.get(i).marke, (int) data.get(i).preis,data.get(i).bild,data.get(i).speicherplatz));
			
			//space between results
			resultPanel.add(Box.createRigidArea(new Dimension(200,50)));
			
		}
		//check if results were found
		if(!data.isEmpty())
		{
			this.add(resultList);
		}else {
                    JOptionPane jOptionPane = new JOptionPane();
			//success message
			JOptionPane.showMessageDialog(this, "Keine Laptop wurde gefunden");
		}
		//refresh GUI
		this.getRootPane().getContentPane().revalidate();
		this.getRootPane().getContentPane().repaint();
	}
    
}

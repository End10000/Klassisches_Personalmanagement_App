/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.UUID;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author nanad
 */
public class ListSeite extends JPanel{
    
    UUID id;
	String marke;
	int preis;
	String bild;
	int  speicherplatz;
	
	JLabel labelmarke = new JLabel();
	JLabel labelspeicherplatz = new JLabel();
	JLabel labelpreis = new JLabel();
	public JButton buttonbestellen = new JButton("Bestellen");
	JLabel labelimage = new JLabel();
	

	
	public ListSeite(UUID id, String marke, int preis, String bild,int speicherplatz)
	{
		this.id = id;
		this.marke = marke;
		this.preis = preis;
		this.bild = bild;
		this.speicherplatz = speicherplatz;
		
		
		//gui stuff
		labelmarke.setText(marke);
		labelmarke.setBounds(10,220,300,30);
		labelmarke.setFont(new Font("Roboto",Font.BOLD,20));
		labelmarke.setForeground(Color.black);
        labelmarke.addMouseListener(new MouseAdapter() {
			
                        @Override
			public void mouseClicked(MouseEvent event) {

                            BestellenSeite1 bestellenSeite1 = new BestellenSeite1(id);
					
				
						}
		});
		
		labelpreis.setText("Preis: " + Integer.toString(preis) + " €");
		labelpreis.setBounds(10,270,300,30);
		labelpreis.setFont(new Font("Roboto",Font.BOLD,20));
		labelpreis.setForeground(Color.black);
        labelpreis.addMouseListener(new MouseAdapter() {
			
                        @Override
			public void mouseClicked(MouseEvent event) {

                           // BestellenSeite1 bestellenSeite1 = new BestellenSeite1(id);
                           new BestellenSeite1(id);
					
				
						}
		});
		
		
		labelimage.setIcon(new ImageIcon(new ImageIcon(bild).getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH)));	
		labelimage.setBounds(0,0,200,200);
		labelimage.addMouseListener(new MouseAdapter() {
			
                        @Override
			public void mouseClicked(MouseEvent event) {

                            BestellenSeite1 bestellenSeite1 = new BestellenSeite1(id);
					
				
						}
		});
		labelspeicherplatz.setText("Speicherplatz: "+ speicherplatz + " Go" );
		labelspeicherplatz.setBounds(10,245,300,30);
		labelspeicherplatz.setFont(new Font("Roboto",Font.ROMAN_BASELINE,15));
		labelspeicherplatz.setForeground(Color.black);
		labelspeicherplatz.addMouseListener(new MouseAdapter() {
			
                        @Override
			public void mouseClicked(MouseEvent event) {

                            BestellenSeite1 bestellenSeite1 = new BestellenSeite1(id);
					
				
						}
		});
		buttonbestellen.setBounds(140,100,150,30);
		buttonbestellen.setFont(new Font("Roboto",Font.ROMAN_BASELINE,16));
		buttonbestellen.setForeground(Color.white);
		buttonbestellen.setBackground(Color.black);
		buttonbestellen.setBorder(null);
		buttonbestellen.setFocusable(false);
	    buttonbestellen.addActionListener((ActionEvent e) -> {
                if(e.getSource()==buttonbestellen) {
                    
                    BestellenSeite1 bestellenSeite1 = new BestellenSeite1(id);
                }
                });
		
		this.setLayout(null);
		this.setBackground(Color.lightGray);
		
		//set correct size, ist zwar bestimmt nicht elegant gelÃ¶st aber was solls
		this.setPreferredSize(new Dimension(200,300));
		this.setMinimumSize(new Dimension(400,100));
		this.setMaximumSize(new Dimension(400,150));
		
		
		this.add(labelmarke);
		this.add(labelpreis);
//		this.add(buttonbestellen);
		this.add(labelimage);
		this.add(labelspeicherplatz);
                
	}

   

    

	public UUID getId() {
		return id;
	}

    
}

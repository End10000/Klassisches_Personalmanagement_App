
package View;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class LinksSeite  extends JPanel{
  
     NeueComputer nc = new NeueComputer();
    NeueSuchen ns = new NeueSuchen();
    NeueListe nl = new NeueListe();
      MenuBild MB = new MenuBild();
    
    JLabel labelhinzufuegen = new JLabel("Hinzufügen ");
    JLabel labelsuche = new JLabel("Suchen");
    JLabel labelliste = new JLabel("Liste");
    JLabel labelHauptseite = new JLabel(new ImageIcon ("image/icons8-home-50.png"));
    JLabel rafraichir = new JLabel("rafraichir");
    
    
    public LinksSeite(){
    setPreferredSize(new Dimension(260,100));
        setLayout(null);
        setBackground(Color.GRAY);
        
        
         labelhinzufuegen.setFont(new Font("Arial",Font.BOLD,25));
        labelhinzufuegen.setBounds(20, 220, 260, 100);
        labelhinzufuegen.setForeground(Color.WHITE);
        labelhinzufuegen.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        labelsuche.setFont(new Font("Arial",Font.BOLD,25));
        labelsuche.setBounds(20, 320, 260, 100);
        labelsuche.setForeground(Color.WHITE);
        labelsuche.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        labelliste.setFont(new Font("Arial",Font.BOLD,25));
        labelliste.setBounds(20, 420, 260, 100);
        labelliste.setForeground(Color.WHITE);
        labelliste.setCursor(new Cursor(Cursor.HAND_CURSOR));
  
        labelHauptseite.setBounds(20, 120, 150, 100);
        labelHauptseite.setCursor(new Cursor(Cursor.HAND_CURSOR));
        labelHauptseite.setToolTipText("zurück zur Hauptseite");
        
        rafraichir.setFont(new Font("Arial",Font.BOLD,25));
        rafraichir.setBounds(20, 510, 260, 100);
        rafraichir.setForeground(Color.WHITE);
        rafraichir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
         add(labelhinzufuegen);
        add(labelsuche);
        add(labelliste);
        add(labelHauptseite);
        /// add( rafraichir);
       labelhinzufuegen.addMouseListener(new MouseListener(){
        @Override
        public void mouseClicked(MouseEvent e) {
           
        }

        @Override
        public void mousePressed(MouseEvent e) {
            createPanelNeueComputer();
            /*  Passwort p = new Passwort();
            if ((p.Username=="gudenkauf")&&(p.Password == "2023")){
                
              createPanelNeueComputer();
            }
            else{
              // JOptionPane .showMessageDialog(LinksSeite.this,"Ihre Eingabe sind falsch, bitte prüfen Sie ihre Username und Password","Nachricht",JOptionPane.INFORMATION_MESSAGE);
                       
            }*/
        }

        @Override
        public void mouseReleased(MouseEvent e) {
          
        }

        @Override
        public void mouseEntered(MouseEvent e) {
                   labelhinzufuegen.setForeground(Color.BLACK);

        }

        @Override
        public void mouseExited(MouseEvent e) {
                   labelhinzufuegen.setForeground(Color.WHITE);

        }
           
       });
       
       
       labelsuche.addMouseListener(new MouseListener(){
        @Override
        public void mouseClicked(MouseEvent e) {
           
        }

        @Override
        public void mousePressed(MouseEvent e) {
           createPanelNeueSuche();
        }

        @Override
        public void mouseReleased(MouseEvent e) {
          
        }

        @Override
        public void mouseEntered(MouseEvent e) {
                   labelsuche.setForeground(Color.BLACK);

        }

        @Override
        public void mouseExited(MouseEvent e) {
                   labelsuche.setForeground(Color.WHITE);

        }
           
       });
       
       
       labelliste.addMouseListener(new MouseListener(){
        @Override
        public void mouseClicked(MouseEvent e) {
           
        }

        @Override
        public void mousePressed(MouseEvent e) {
           createPanelNeueListe();
        }

        @Override
        public void mouseReleased(MouseEvent e) {
          
        }

        @Override
        public void mouseEntered(MouseEvent e) {
                   labelliste.setForeground(Color.BLACK);

        }

        @Override
        public void mouseExited(MouseEvent e) {
                   labelliste.setForeground(Color.WHITE);

        }
           
       });
       
       
       
       
       
       
       
       labelHauptseite.addMouseListener(new MouseListener(){
        @Override
        public void mouseClicked(MouseEvent e) {
           
        }

        @Override
        public void mousePressed(MouseEvent e) {
           createPanelMenuBild();
        }

        @Override
        public void mouseReleased(MouseEvent e) {
          
        }

        @Override
        public void mouseEntered(MouseEvent e) {
                 

        }

        @Override
        public void mouseExited(MouseEvent e) {
                  

        }
           
       });
       
       
       
       
       
       
        
      rafraichir.addMouseListener(new MouseListener(){
        @Override
        public void mouseClicked(MouseEvent e) {
           
        }

        @Override
        public void mousePressed(MouseEvent e) {
        
           getRootPane().getContentPane().add(nl);
          
       
     nl.revalidate();
        nl.repaint();
            
       
        }

        @Override
        public void mouseReleased(MouseEvent e) {
          
        }

        @Override
        public void mouseEntered(MouseEvent e) {
                   rafraichir.setForeground(Color.BLACK);

        }

        @Override
        public void mouseExited(MouseEvent e) {
                   rafraichir.setForeground(Color.WHITE);

        }
           
       });
       
    }
    
     private JPanel createPanelNeueComputer(){
    
        getRootPane().getContentPane().remove(MB);
        getRootPane().getContentPane().remove(nl);
        getRootPane().getContentPane().remove(ns);
        getRootPane().getContentPane().add(nc);
        
    
        nc.revalidate();
        nc.repaint();
    return nc;
    }
     
     
     private JPanel createPanelNeueSuche(){
    
         getRootPane().getContentPane().remove(MB);
        getRootPane().getContentPane().remove(nl);
        getRootPane().getContentPane().remove(nc);
        getRootPane().getContentPane().add(ns);
        
    
        ns.revalidate();
        ns.repaint();
    return ns;
    }
     
     
     private JPanel createPanelNeueListe(){
    
        getRootPane().getContentPane().remove(MB);
        getRootPane().getContentPane().remove(ns);
        getRootPane().getContentPane().remove(nc);
        getRootPane().getContentPane().add(nl);
        
    
        nl.revalidate();
        nl.repaint();
      
         
    return nl;
     
    }
     
     
     private JPanel createPanelMenuBild(){
    
        getRootPane().getContentPane().remove(ns);
        getRootPane().getContentPane().remove(nl);
        getRootPane().getContentPane().remove(nc);
        getRootPane().getContentPane().add(MB);
        
    
        MB.revalidate();
        MB.repaint();
    return MB;
    }
    
    
    
    
}

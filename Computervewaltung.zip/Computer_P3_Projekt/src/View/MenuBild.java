
package View;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class MenuBild extends JPanel{
    
    public JLabel labelauto = new JLabel(new ImageIcon("image/R.png"));
    public JLabel titel = new JLabel("                                                  COMPUTERVERWALTUNG");
    
    public MenuBild(){
    
        titel.setFont(new Font("Roboto",Font.BOLD,24));
        setLayout(new BorderLayout());
        add(labelauto,BorderLayout.CENTER);
        add(titel,BorderLayout.NORTH);
    }
    
    
    
    
}


        document.querySelector(".menue").addEventListener("click",newmenu);
        document.querySelector(".close").addEventListener("click",cmenu);
        document.querySelector("form").addEventListener("submit",speichernauswerten);
		window.addEventListener("load",IDberechnen);
   
        function newmenu(){

           
           document.querySelector(".box2").classList.toggle("box2content");
         
        }
        function cmenu(){

           
            document.querySelector(".box2").classList.remove("box2content");
          
         }

// Berechnet die nächst freier ID 
		 function IDberechnen(){
			fetch('../JSON/Liste.json', {												
				method: 'get',												
				cache: 'no-store'											
		})
		.then(function(response) {											
			return response.json();											
		})
		.then(function(mitarbeitern) {
		
		   
		
			 
			
		var IDLaenge = mitarbeitern.length;
		var IDAlle = [];
												
		for(var i = 0; i<IDLaenge; i++)	{
			IDAlle.push(mitarbeitern[i].ID);

			 
				 }

				 var IDMax = 0;
				 IDMax = Math.max.apply(null,IDAlle);
				 IDMax=IDMax+1;
				 IDNeu = IDMax;
				 if(IDLaenge){
				 document.querySelector("#next-free-id").innerHTML=IDNeu;
				}else{
					document.querySelector("#next-free-id").innerHTML=1;
				}

		})
		.catch(function(error) {											
			alert(error);													
		});
		

		 }

// Prüefe die Eingabe in dem Formular,ob das korrekt sind
           function speichernauswerten(){
			let isValid = true;

          if (document.forms["einfuegen"].elements["ID"].value.length < 1|| isNaN(document.forms["einfuegen"].elements["ID"].value) ) {										
				document.querySelector(".errorid").innerHTML='Muss mindestens ein Ziffer sein.';													
				document.forms["einfuegen"].elements["ID"].focus();													
				event.preventDefault();	
				document.querySelector("#id").classList.remove("farbegruen");
				document.querySelector("#id").classList.add("farberot");
				document.querySelector(".icon-richtig1").classList.remove("icon-anzeigen");
				document.querySelector(".icon-falsch1").classList.add("icon-anzeigen");
				isValid = false;
				
																						
			}else {
				
				document.querySelector(".errorid").innerHTML='';
				document.querySelector("#id").classList.remove("farberot");
				document.querySelector("#id").classList.add("farbegruen");
				document.querySelector(".icon-falsch1").classList.remove("icon-anzeigen");
				document.querySelector(".icon-richtig1").classList.add("icon-anzeigen");
			
				
			
		
			
			}	
          
            if (document.forms["einfuegen"].elements["NAME"].value.length < 2) {										
				document.querySelector(".errorname").innerHTML='Muss mindestens zwei Buchstaben sein.';												
				document.forms["einfuegen"].elements["NAME"].focus();													
				event.preventDefault();	
				document.querySelector("#name").classList.remove("farbegruen");
				document.querySelector("#name").classList.add("farberot");
				document.querySelector(".icon-richtig2").classList.remove("icon-anzeigen");
				document.querySelector(".icon-falsch2").classList.add("icon-anzeigen");
				isValid = false;															
			}	
			
			
			else {
				document.querySelector(".errorname").innerHTML='';	
				document.querySelector("#name").classList.remove("farberot");
				document.querySelector("#name").classList.add("farbegruen");
				document.querySelector(".icon-falsch2").classList.remove("icon-anzeigen");
				document.querySelector(".icon-richtig2").classList.add("icon-anzeigen");
				
		
			
			}
			


            if (document.forms["einfuegen"].elements["VORNAME"].value.length < 2) {										
				document.querySelector(".errorvorname").innerHTML='Muss mindestens zwei Buchstaben sein.';												
				document.forms["einfuegen"].elements["VORNAME"].focus();													
				event.preventDefault();	
				document.querySelector("#vorname").classList.remove("farbegruen");
				document.querySelector("#vorname").classList.add("farberot");
				document.querySelector(".icon-richtig3").classList.remove("icon-anzeigen");
				document.querySelector(".icon-falsch3").classList.add("icon-anzeigen");
				isValid = false;																		
			}else {
				document.querySelector(".errorvorname").innerHTML='';
				document.querySelector("#vorname").classList.remove("farberot");
				document.querySelector("#vorname").classList.add("farbegruen");	
				document.querySelector(".icon-falsch3").classList.remove("icon-anzeigen");
				document.querySelector(".icon-richtig3").classList.add("icon-anzeigen");
				
			}
			
            if (document.forms["einfuegen"].elements["ALTER"].value.length < 1 || isNaN(document.forms["einfuegen"].elements["ALTER"].value)) {										
				document.querySelector(".erroralter").innerHTML='Muss mindestens zwei Ziffern sein.';												
				document.forms["einfuegen"].elements["ALTER"].focus();													
				event.preventDefault();	
				document.querySelector("#alter").classList.remove("farbegruen");
				document.querySelector("#alter").classList.add("farberot");	
				document.querySelector(".icon-richtig4").classList.remove("icon-anzeigen");
				document.querySelector(".icon-falsch4").classList.add("icon-anzeigen");	
				isValid = false;																
			}else {
				document.querySelector(".erroralter").innerHTML='';	
				document.querySelector("#alter").classList.remove("farberot");
				document.querySelector("#alter").classList.add("farbegruen");
				document.querySelector(".icon-falsch4").classList.remove("icon-anzeigen");
				document.querySelector(".icon-richtig4").classList.add("icon-anzeigen");
				
			}
            if (document.forms["einfuegen"].elements["WOHNORT"].value.length < 2) {										
				document.querySelector(".errorwohnort").innerHTML='Muss mindestens zwei Buchstaben sein.';										
				document.forms["einfuegen"].elements["WOHNORT"].focus();													
				event.preventDefault();	
				document.querySelector("#wohnort").classList.remove("farbegruen");
				document.querySelector("#wohnort").classList.add("farberot");
				document.querySelector(".icon-richtig5").classList.remove("icon-anzeigen");
				document.querySelector(".icon-falsch5").classList.add("icon-anzeigen");	
				isValid = false;	
																				
			}else {
				document.querySelector(".errorwohnort").innerHTML='';
				document.querySelector("#wohnort").classList.remove("farberot");
				document.querySelector("#wohnort").classList.add("farbegruen");	
				document.querySelector(".icon-falsch5").classList.remove("icon-anzeigen");
				document.querySelector(".icon-richtig5").classList.add("icon-anzeigen");
				
					
			}
            if (document.forms["einfuegen"].elements["TELEFON"].value.length < 9 || isNaN(document.forms["einfuegen"].elements["TELEFON"].value)) {										
				document.querySelector(".errortelefon").innerHTML='Muss mindestens neun Ziffern sein.';												
				document.forms["einfuegen"].elements["TELEFON"].focus();													
				event.preventDefault();	
				document.querySelector("#telefon").classList.remove("farbegruen");
				document.querySelector("#telefon").classList.add("farberot");	
				document.querySelector(".icon-richtig6").classList.remove("icon-anzeigen");
				document.querySelector(".icon-falsch6").classList.add("icon-anzeigen");
				isValid = false;	
																					
			}else {
				document.querySelector(".errortelefon").innerHTML='';
				document.querySelector("#telefon").classList.remove("farberot");	
				document.querySelector("#telefon").classList.add("farbegruen");
				document.querySelector(".icon-falsch6").classList.remove("icon-anzeigen");
				document.querySelector(".icon-richtig6").classList.add("icon-anzeigen");
				
			}
            if ((document.forms['einfuegen'].elements['EMAIL'].value.indexOf('@') == -1) ||							
				(document.forms['einfuegen'].elements['EMAIL'].value.indexOf('.') == -1)) {							
				document.querySelector(".erroremail").innerHTML='Bitte überprüfen Sie die E-mail Adresse.';										
				document.forms['einfuegen'].elements['EMAIL'].focus();												
				event.preventDefault();	
				document.querySelector("#email").classList.remove("farbegruen");
				document.querySelector("#email").classList.add("farberot");	
				document.querySelector(".icon-richtig7").classList.remove("icon-anzeigen");
				document.querySelector(".icon-falsch7").classList.add("icon-anzeigen");
				isValid = false;	
																				
			}else {
				document.querySelector(".erroremail").innerHTML='';	
				document.querySelector("#email").classList.remove("farberot");
				document.querySelector("#email").classList.add("farbegruen");
				document.querySelector(".icon-falsch7").classList.remove("icon-anzeigen");
				document.querySelector(".icon-richtig7").classList.add("icon-anzeigen");
				
			}
            
            if (document.forms["einfuegen"].elements["AUFGABE"].value.length < 2) {										
				document.querySelector(".erroraufgabe").innerHTML='Muss mindestens zwei Buchstaben sein.';											
				document.forms["einfuegen"].elements["AUFGABE"].focus();													
				event.preventDefault();	
				document.querySelector("#aufgabe").classList.remove("farbegruen");
				document.querySelector("#aufgabe").classList.add("farberot");
				document.querySelector(".icon-richtig8").classList.remove("icon-anzeigen");
				document.querySelector(".icon-falsch8").classList.add("icon-anzeigen");	
				isValid = false;	
																					
			}
			else {
				document.querySelector(".erroraufgabe").innerHTML='';
				document.querySelector("#aufgabe").classList.remove("farberot");
				document.querySelector("#aufgabe").classList.add("farbegruen");	
				document.querySelector(".icon-falsch8").classList.remove("icon-anzeigen");
				document.querySelector(".icon-richtig8").classList.add("icon-anzeigen");
				
			}

			if (!document.forms['einfuegen'].elements['IMAGE'].files[0]) {								
				document.querySelector(".errorbild").innerHTML='Bitte laden Sie ein Bild hoch.';												
				document.forms['einfuegen'].elements['IMAGE'].focus();											
				event.preventDefault();	
				isValid = false;	
			
				
																						
			} else {
				document.querySelector(".errorbild").innerHTML='';	
			
			}

            if (document.forms['einfuegen'].elements['DATENSCHUTZ'].checked == false) {								
				document.querySelector(".errorschutz").innerHTML='Bitte Stimmen Sie die Datenschutz zu.';												
				document.forms['einfuegen'].elements['DATENSCHUTZ'].focus();											
				event.preventDefault();	
				isValid = false;	
			
				
																						
			} else {
				document.querySelector(".errorschutz").innerHTML='';	
			
			}

			if (isValid) {
				DatenErstellen.call(this);
			  }
			  else {
				alert("Bitte füllen Sie alle Felder aus!");
			  }
          
         }

// Erstellt die Daten und durch post schickt  sie und warte ein Antwort von php

         async function DatenErstellen() {
			event.preventDefault();											
  const Eingaben = new FormData(this);
  




  try{					
	const response = await fetch('../PHP/mitarbeiter einfuegen.php', {									
	  method: 'post',												
	  body: Eingaben												
  })

			if (response.ok) {
				alert("Ein neuer Mitarbeiter wurde erfolgreich eingefügt");
				document.querySelector('form').reset();
				location.reload();
				// Nachtricht ,wenn die Eingegebene ID  schon in Json Datei  vorhanden ist
			  } else if (response.status === 409) {
				alert("Diese ID existiert schon ! Die Abspeicherung ist unmöglich");
			  } else {
				throw new Error ("Es gab einen Fehler beim Einfügen des Mitarbeiters");
			  }
			} catch (error) {
			  alert(error.message);
			}

			
		

}

		
document.querySelector(".menue").addEventListener("click",newmenu);
        document.querySelector(".close").addEventListener("click",cmenu);
        document.querySelector("form").addEventListener("submit",speichernauswerten);
		window.addEventListener("load",DatenEmpfangen);
	
   

        function newmenu(){

           
           document.querySelector(".box2").classList.toggle("box2content");
         
        }
        function cmenu(){

           
            document.querySelector(".box2").classList.remove("box2content");
          
         }

         function speichernauswerten(){
			let isValid = true;

           if (document.forms["einfuegen"].elements["ID"].value.length < 1|| isNaN(document.forms["einfuegen"].elements["ID"].value) ) {										
				document.querySelector(".errorid").innerHTML='Muss mindestens ein Ziffer sein.';													
				document.forms["einfuegen"].elements["ID"].focus();													
				event.preventDefault();	
				document.querySelector("#id").classList.remove("farbegruen");
				document.querySelector("#id").classList.add("farberot");
				isValid = false;
				
																						
			}else {
				document.querySelector(".errorid").innerHTML='';
				document.querySelector("#id").classList.remove("farberot");
				document.querySelector("#id").classList.add("farbegruen");
				
			
			
			
			}
          
            if (document.forms["einfuegen"].elements["NAME"].value.length < 2) {										
				document.querySelector(".errorname").innerHTML='Muss mindestens zwei Buchstaben sein.';												
				document.forms["einfuegen"].elements["NAME"].focus();													
				event.preventDefault();	
				document.querySelector("#name").classList.remove("farbegruen");
				document.querySelector("#name").classList.add("farberot");
				isValid = false;															
			}	
			
			
			else {
				document.querySelector(".errorname").innerHTML='';	
				document.querySelector("#name").classList.remove("farberot");
				document.querySelector("#name").classList.add("farbegruen");
		
			
			}
			


            if (document.forms["einfuegen"].elements["VORNAME"].value.length < 2) {										
				document.querySelector(".errorvorname").innerHTML='Muss mindestens zwei Buchstaben sein.';												
				document.forms["einfuegen"].elements["VORNAME"].focus();													
				event.preventDefault();	
				document.querySelector("#vorname").classList.remove("farbegruen");
				document.querySelector("#vorname").classList.add("farberot");
				isValid = false;																		
			}else {
				document.querySelector(".errorvorname").innerHTML='';
				document.querySelector("#vorname").classList.remove("farberot");
				document.querySelector("#vorname").classList.add("farbegruen");	
			}
			
            if (document.forms["einfuegen"].elements["ALTER"].value.length < 1 || isNaN(document.forms["einfuegen"].elements["ALTER"].value)) {										
				document.querySelector(".erroralter").innerHTML='Muss mindestens zwei Ziffern sein.';												
				document.forms["einfuegen"].elements["ALTER"].focus();													
				event.preventDefault();	
				document.querySelector("#alter").classList.remove("farbegruen");
				document.querySelector("#alter").classList.add("farberot");		
				isValid = false;																
			}else {
				document.querySelector(".erroralter").innerHTML='';	
				document.querySelector("#alter").classList.remove("farberot");
				document.querySelector("#alter").classList.add("farbegruen");
			}
            if (document.forms["einfuegen"].elements["WOHNORT"].value.length < 2) {										
				document.querySelector(".errorwohnort").innerHTML='Muss mindestens zwei Buchstaben sein.';										
				document.forms["einfuegen"].elements["WOHNORT"].focus();													
				event.preventDefault();	
				document.querySelector("#wohnort").classList.remove("farbegruen");
				document.querySelector("#wohnort").classList.add("farberot");	
				isValid = false;	
																				
			}else {
				document.querySelector(".errorwohnort").innerHTML='';
				document.querySelector("#wohnort").classList.remove("farberot");
				document.querySelector("#wohnort").classList.add("farbegruen");	
					
			}
            if (document.forms["einfuegen"].elements["TELEFON"].value.length < 9 || isNaN(document.forms["einfuegen"].elements["TELEFON"].value)) {										
				document.querySelector(".errortelefon").innerHTML='Muss mindestens neun Ziffern sein.';												
				document.forms["einfuegen"].elements["TELEFON"].focus();													
				event.preventDefault();	
				document.querySelector("#telefon").classList.remove("farbegruen");
				document.querySelector("#telefon").classList.add("farberot");	
				isValid = false;	
																					
			}else {
				document.querySelector(".errortelefon").innerHTML='';
				document.querySelector("#telefon").classList.remove("farberot");	
				document.querySelector("#telefon").classList.add("farbegruen");
			}
            if ((document.forms['einfuegen'].elements['EMAIL'].value.indexOf('@') == -1) ||							
				(document.forms['einfuegen'].elements['EMAIL'].value.indexOf('.') == -1)) {							
				document.querySelector(".erroremail").innerHTML='Bitte überprüfen Sie die E-mail Adresse.';										
				document.forms['einfuegen'].elements['EMAIL'].focus();												
				event.preventDefault();	
				document.querySelector("#email").classList.remove("farbegruen");
				document.querySelector("#email").classList.add("farberot");	
				isValid = false;	
																				
			}else {
				document.querySelector(".erroremail").innerHTML='';	
				document.querySelector("#email").classList.remove("farberot");
				document.querySelector("#email").classList.add("farbegruen");
			}
            
            if (document.forms["einfuegen"].elements["AUFGABE"].value.length < 2) {										
				document.querySelector(".erroraufgabe").innerHTML='Muss mindestens zwei Buchstaben sein.';											
				document.forms["einfuegen"].elements["AUFGABE"].focus();													
				event.preventDefault();	
				document.querySelector("#aufgabe").classList.remove("farbegruen");
				document.querySelector("#aufgabe").classList.add("farberot");	
				isValid = false;	
																					
			}
			else {
				document.querySelector(".erroraufgabe").innerHTML='';
				document.querySelector("#aufgabe").classList.remove("farberot");
				document.querySelector("#aufgabe").classList.add("farbegruen");	
			}

			if (!document.forms['einfuegen'].elements['IMAGE'].files[0]) {								
				document.querySelector(".errorbild").innerHTML='Bitte laden Sie ein Bild hoch.';												
				document.forms['einfuegen'].elements['IMAGE'].focus();											
				event.preventDefault();	
				isValid = false;	
			
				
																						
			} else {
				document.querySelector(".errorbild").innerHTML='';	
			
			}

            if (document.forms['einfuegen'].elements['DATENSCHUTZ'].checked == false) {								
				document.querySelector(".errorschutz").innerHTML='Bitte Stimmen Sie die Datenschutz zu.';												
				document.forms['einfuegen'].elements['DATENSCHUTZ'].focus();											
				event.preventDefault();	
				isValid = false;	
			
				
																						
			} else {
				document.querySelector(".errorschutz").innerHTML='';	
			
			}

			if (isValid) {
				DatenAktualisieren.call(this);
			  }
			  else {
				alert("Bitte füllen Sie alle Felder aus!");
			  }
          
         }


         
			async function DatenAktualisieren(){
                event.preventDefault();
                const Eingaben = new FormData(this);
                await fetch ("../PHP/Mitarbeiter Aktualisieren.php",{
            
                    method:"post",
                    body:Eingaben
                })
            
                .then(function(response){
                 alert(" Die Mitarbeiterdaten wurden erfolgreich aktualisiert");
				 document.querySelector("form").reset();
				 location.reload();
            
                })
                .catch(function(error){
                    alert(error);
                
                });
                
               
            }	
			
			/*function DatenEmpfangen(){

				fetch('../JSON/Liste.json', {												
					method: 'get',												
					cache: 'no-store'											
			})
			.then(function(response) {											
				return response.json();											
			})
			.then(function(mitarbeitern) {
			
			
			
													
			

				
				for(var i = 0; i<mitarbeitern.length; i++)	{
			
			document.querySelector("#id").value=mitarbeitern[i].ID;				
			document.querySelector("#name").value=mitarbeitern[i].Name 					
			document.querySelector("#vorname").value=mitarbeitern[i].Vorname				
			document.querySelector("#alter").value=mitarbeitern[i].Alter 	
			document.querySelector("#telefon").value=mitarbeitern[i].Telefon 					
			document.querySelector("#wohnort").value=mitarbeitern[i].Wohnort   
			document.querySelector("#email").value=mitarbeitern[i].Email                   
			document.querySelector("#aufgabe").value=mitarbeitern[i].Aufgabe 
				
			
				}		 
			
			})
			.catch(function(error) {											
				alert(error);													
			});
			
			}
		
*/
			
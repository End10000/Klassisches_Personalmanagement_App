<?php

$Bestand = json_decode(file_get_contents('../JSON/Liste.json'),true);
// Delete eine zeile von der Json-datei durch die ID
foreach ($Bestand as $key => $value) {
	if ($value['ID'] === intval($_POST['ID'])) {
		$Index = intval($key);
		array_splice($Bestand,$Index,1);
	}
}

file_put_contents('../JSON/Liste.json',json_encode($Bestand,JSON_PRETTY_PRINT),LOCK_EX);


?>
<?php

$Bestand = json_decode(file_get_contents('../JSON/Liste.json'),true);
// aktualisieren wo die eingebene ID gleich wie die ID in JSon -Datei
foreach ($Bestand as $key => $value) {
	if ($value['ID'] === intval($_POST['ID'])) {
		$Bestand[$key]['Name'] = $_POST['NAME'];
        $Bestand[$key]['Vorname'] = $_POST['VORNAME'];
        $Bestand[$key]['Alter'] = intval($_POST['ALTER']);
        $Bestand[$key]['Wohnort'] = $_POST['WOHNORT'];
        $Bestand[$key]['Telefon'] = $_POST['TELEFON'];
        $Bestand[$key]['Email'] = $_POST['EMAIL'];
        $Bestand[$key]['Aufgabe'] = $_POST['AUFGABE'];
        $Bestand[$key]['Bild'] = "../image/".$_FILES['IMAGE']['name'];
        move_uploaded_file($_FILES['IMAGE']['tmp_name'],  $Bestand[$key]['Bild']);
	}
}

file_put_contents('../JSON/Liste.json',json_encode($Bestand,JSON_PRETTY_PRINT),LOCK_EX);

?>
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.UUID;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author nanad
 */
public class ListSeite2 extends JPanel{
       UUID id;
	String marke;
	int preis;
	String bild;
	int  speicherplatz;
	
	JLabel labelmarke = new JLabel();
	JLabel labelspeicherplatz = new JLabel();
	JLabel labelpreis = new JLabel();
	public JButton buttonbestellen = new JButton("Bestellen");
	JLabel labelimage = new JLabel();
	

	
	public ListSeite2 (UUID id, String marke, int preis, String bild,int speicherplatz)
	{
		this.id = id;
		this.marke = marke;
		this.preis = preis;
		this.bild = bild;
		this.speicherplatz = speicherplatz;
		
		
		//gui stuff
		labelmarke.setText(marke);
		labelmarke.setBounds(140,7,300,30);
		labelmarke.setFont(new Font("Roboto",Font.BOLD,20));
		labelmarke.setForeground(Color.white);
        labelmarke.addMouseListener(new MouseAdapter() {
			
                        @Override
			public void mouseClicked(MouseEvent event) {

                            BestellenSeite1 bestellenSeite1 = new BestellenSeite1(id);
					
				
						}
		});
		
		labelpreis.setText("Preis: " + Integer.toString(preis) + " €");
		labelpreis.setBounds(140,70,300,30);
		labelpreis.setFont(new Font("Roboto",Font.BOLD,20));
		labelpreis.setForeground(Color.white);
        labelpreis.addMouseListener(new MouseAdapter() {
			
                        @Override
			public void mouseClicked(MouseEvent event) {

                            BestellenSeite1 bestellenSeite1 = new BestellenSeite1(id);
					
				
						}
		});
		
		
		labelimage.setIcon(new ImageIcon(new ImageIcon(bild).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)));	
		labelimage.setBounds(0,0,100,100);
		labelimage.addMouseListener(new MouseAdapter() {
			
                        @Override
			public void mouseClicked(MouseEvent event) {

                            BestellenSeite1 bestellenSeite1 = new BestellenSeite1(id);
					
				
						}
		});
		labelspeicherplatz.setText("Speicherplatz: "+ speicherplatz + " Go" );
		labelspeicherplatz.setBounds(140,40,300,30);
		labelspeicherplatz.setFont(new Font("Roboto",Font.ROMAN_BASELINE,18));
		labelspeicherplatz.setForeground(Color.black);
		labelspeicherplatz.addMouseListener(new MouseAdapter() {
			
                        @Override
			public void mouseClicked(MouseEvent event) {

                            BestellenSeite1 bestellenSeite1 = new BestellenSeite1(id);
					
				
						}
		});
		buttonbestellen.setBounds(140,100,150,30);
		buttonbestellen.setFont(new Font("Roboto",Font.ROMAN_BASELINE,16));
		buttonbestellen.setForeground(Color.white);
		buttonbestellen.setBackground(Color.black);
		buttonbestellen.setBorder(null);
		buttonbestellen.setFocusable(false);
	    buttonbestellen.addActionListener((ActionEvent e) -> {
                if(e.getSource()==buttonbestellen) {
                    
                    BestellenSeite1 bestellenSeite1 = new BestellenSeite1(id);
                }
                });
		
		this.setLayout(null);
		this.setBackground(Color.MAGENTA);
		
		//set correct size, ist zwar bestimmt nicht elegant gelÃ¶st aber was solls
		this.setPreferredSize(new Dimension(400,150));
		this.setMinimumSize(new Dimension(400,100));
		this.setMaximumSize(new Dimension(400,150));
		
		
		add(labelmarke);
		add(labelpreis);
//		this.add(buttonbestellen);
		add(labelimage);
		add(labelspeicherplatz);
	}

    

	public UUID getId() {
		return id;
	}

    
    
}

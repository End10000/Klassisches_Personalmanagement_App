
package Database;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.swing.JLabel;



public class Datenbank {
    
    public static List<LaptopModell> list = new ArrayList<>();
	
	//read whole database
	public static void readData() {
		list.removeAll(list);
		try(BufferedReader br = new BufferedReader(new FileReader("database.csv")))
		{
			String line;
			//skip first line
			br.readLine();
			while((line=br.readLine()) != null)
			{
				String[] values = line.split(";");
				
				list.add(
						new LaptopModell(UUID.fromString(values[0]),values[1],Integer.parseInt(values[2]),values[3],Integer.parseInt(values[4]),Float.parseFloat(values[5]),values[6],Boolean.parseBoolean(values[7]),line)
						);
			}
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	//find data by given id
	public static LaptopModell findById(UUID id)
	{
		readData();
		for(int i=0;i<list.size();i++)
		{
			LaptopModell record = list.get(i);
			if(record.id.equals(id))
			{
				return record;
				
			}else if(i+1==list.size())
			{
				System.out.println("Keine Daten mit diesem:" + id + "gefunden");	
			}
		}
		return null;
	}
	//find data based on different values
	//public static List<SchuhModell> findData(UUID id, String Marke, int Größe, String Farbe,String Träger,  float Preis)
	public static List<LaptopModell> findData()
	{
		List<LaptopModell> models= new ArrayList<>();
		readData();
		for(int i=0;i<list.size();i++)
		{
			LaptopModell target = list.get(i);
			
				 
				
				
			{
				models.add(target);
			} if(i+1 == list.size())
			{
			
			}
		}
		return models;
	}
        
        
        
        
        public static List<LaptopModell> findData2(UUID id, String Marke)
	{
		List<LaptopModell> models= new ArrayList<>();
		readData();
		for(int i=0;i<list.size();i++)
		{
			LaptopModell target = list.get(i);
			
                          if ( (target.id == id || id == null)&&
                                  target.marke.toLowerCase().contains(Marke.toLowerCase()))
				 
				
				
			{
				models.add(target);
			} else if(i+1 == list.size())
			{
						
			}
		}
		return models;
	}
        
        
        
       
	
	//update data based on given id
	public static void updateData(UUID id, String Marke,int Speicherplatz, String Prozessor,  int Arbeitsspeicher,  float Preis, String Bild,boolean Gebraucht)
	{
		 LaptopModell target = findById(id);
		
		//update only the changed values
		if("".equals(Marke))Marke=target.marke;
		if(Speicherplatz == 0)Speicherplatz=target.speicherplatz;
		if("".equals(Prozessor))Prozessor=target.prozessor;
		if(Arbeitsspeicher== 0)Arbeitsspeicher=target.arbeitsspeicher;
		if(Preis == 0)Preis = target.preis;
   		if("".equals(Bild))Bild=target.bild;
                // ici si il ya ya faute 
		
		try(PrintWriter writer = new PrintWriter(new File("database.csv"))){
			writer.write("id;Marke;Speicherplatz;Prozessor;Arbeitsspeicher;Preis;bildSource;Gebraucht\n");
			System.out.println(list.size());
			
			for(int i=0;i<list.size();i++)
			{
				LaptopModell record = list.get(i);
				if(record.id.equals(id))
				{
					//update line
					writer.write(id + ";" + Marke + ";" + Speicherplatz + ";" + Prozessor + ";" + Arbeitsspeicher + ";" + Preis +";" +Bild+ ";" +Gebraucht +"\n");
				}else
				{
					//copy existing lines
    				writer.write(record.id + ";" + record.marke + ";" + record.speicherplatz + ";" + record.prozessor + ";"+ record.arbeitsspeicher + ";" + record.preis + ";"  + record.bild + ";" + record.gebraucht +"\n");
				}
			}
			
			writer.close();
			System.out.println(" erfolgreiche  Änderung");
		}catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
	//add a new line/model
	public void addData(UUID id, String Marke,int Speicherplatz, String Prozessor,  int Arbeitsspeicher,  float Preis, String Bild,boolean Gebraucht  )
	{
		//generate new random id
		readData();
		UUID newID = UUID.randomUUID();
		
		try(BufferedWriter bw = new BufferedWriter(new FileWriter("database.csv",true)))
		{
			bw.append(newID + ";"  + Marke + ";" + Speicherplatz + ";" + Prozessor + ";" + Arbeitsspeicher + ";" + Preis +";" +Bild+";" +Gebraucht+ "\n");
			bw.close();
			System.out.println("Laptop wurde erfolgreich  hinzugefügt");
		} catch (IOException e) {
		}
	}
	
	
	
	
	//delete a line/model
	public static void deleteData(UUID id)
	{
		LaptopModell target = findById(id);
		//remove line
		list.remove(target);
		
		//write new database
		try(PrintWriter writer = new PrintWriter(new File("database.csv"))){
			writer.write("id;Marke;Speicherplatz;Prozessor;Arbeitsspeicher;Preis;BildSource;Gebraucht\n");
			System.out.println(list.size());
			
			for(int i=0;i<list.size();i++)
			{
				LaptopModell record = list.get(i);
				//rewrite all records.... not that efficient, I know
				writer.write(record.id + ";" + record.marke + ";" + record.speicherplatz + ";" + record.prozessor + ";" + record.arbeitsspeicher + ";" + record.preis  + ";" + record.bild  +";" +record.gebraucht+"\n");
			}
			
			writer.close();
			System.out.println("Laptop wurde erfolgreich gelöscht ");
		}catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	
		

	}

    
    
}

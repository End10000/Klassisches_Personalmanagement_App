<?php
$Mitarbeiter = [];
//$Mitarbeiter['ID'] = uniqid();
$Mitarbeiter['ID'] = intval($_POST['ID']);
$Mitarbeiter['Name'] = $_POST['NAME'];
$Mitarbeiter['Vorname'] = $_POST['VORNAME'];
$Mitarbeiter['Alter'] = intval($_POST['ALTER']);
$Mitarbeiter['Wohnort'] = $_POST['WOHNORT'];
$Mitarbeiter['Telefon'] = $_POST['TELEFON'];
$Mitarbeiter['Email'] = $_POST['EMAIL'];
$Mitarbeiter['Aufgabe'] = $_POST['AUFGABE'];
$Mitarbeiter['Bild'] = "../image/" . $_FILES['IMAGE']['name'];

if (move_uploaded_file($_FILES['IMAGE']['tmp_name'], $Mitarbeiter['Bild'])) {
    echo "Das Foto wurde erfolgreich kopiert.";
} else {
    echo 'Es gab einen Fehler während des Kopierens.';
}



$BestandAlt = json_decode(file_get_contents('../JSON/Liste.json'), true);

// prüfen ob die ID schon existiert 
$idExiste = false;
foreach ($BestandAlt as $existingMitarbeiter) {
    if ($existingMitarbeiter['ID'] === $Mitarbeiter['ID']) {
        $idExiste = true;
        break;
    }
}

if ($idExiste) {
	http_response_code(409);
    echo "Dieses ID existiert schon";
} else {
    // zuweisung in der Bestand
    $BestandAlt[] = $Mitarbeiter;

	// croissante Sortierung 
    usort($BestandAlt, function ($a, $b) {
        return $a['ID'] - $b['ID'];
    });


    file_put_contents('../JSON/Liste.json', json_encode($BestandAlt, JSON_PRETTY_PRINT), LOCK_EX);
    echo "Mitarbeiter erfolgreich eingefügt";
}


?>
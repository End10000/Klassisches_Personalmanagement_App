document.querySelector(".menue").addEventListener("click",newmenu);
        document.querySelector(".close").addEventListener("click",cmenu);

        function newmenu(){

           
           document.querySelector(".box2").classList.toggle("box2content");
         
        }
        function cmenu(){

           
            document.querySelector(".box2").classList.remove("box2content");
          
         }
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author nanad
 */
public class BestellInfo extends JPanel {
    
    JLabel name = new JLabel("Name");
	JLabel vorname = new JLabel("Vorname");
	JLabel straße  = new JLabel("Straße + Nr.");
	JLabel  stadt = new JLabel("plz + Stadt");
	
	public JTextField textname = new JTextField();
	public JTextField textvorname = new JTextField();
	public JTextField textstraße = new JTextField();
	public JTextField textstadt = new JTextField();
	JButton buttonspeichern = new JButton("Speichern");
	public BestellInfo() {
		
		setLayout(null);
		setBackground(Color.white);
		
		name.setBounds(230,75,400,30);
		textname.setBounds(270,75,400,30);
		vorname.setBounds(210,150,400,30);
		textvorname.setBounds(270,150,400,30);
		straße.setBounds(190,225,400,30);
		textstraße.setBounds(270,225,400,30);
		stadt.setBounds(200,300,400,30);
		textstadt.setBounds(270,300,400,30);
		
		
		buttonspeichern.setBounds(400,400,130,30);
		buttonspeichern.setBackground(Color.blue);
		buttonspeichern.setIcon(new ImageIcon("icon/speichern.png"));
		buttonspeichern.addActionListener((ActionEvent e) -> {
                    if(e.getSource()==buttonspeichern) {
                        String Straße = textstraße.getText();
                        String Stadt = textstadt.getText();
                        String Name = textname.getText();
                        String Vorname = textvorname.getText();
                        JOptionPane .showMessageDialog(BestellInfo.this,"Dieses Artikel wird an"+" "+Straße+" , "+Stadt+" "+"geliefert","Liebe/r Frau/Herr"+" "+Name+","+Vorname,JOptionPane.INFORMATION_MESSAGE);
                        textname.setText("");
                        textvorname.setText("");
                        textstadt.setText("");
                        textstraße.setText("");
                        
                    }
                });
		add(buttonspeichern);	
		
		add(textname);
		add(textvorname);
		add(textstraße);
		add(textstadt);
		
		add(name);
		add(vorname);
		add(straße);
		add(stadt);
		
		
	}
	
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Database.Datenbank;
import Database.LaptopModell;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author nanad
 */
public class AenderungSeite extends JFrame{
    public String bildSource  ;
	BestellInfo bi = new BestellInfo();
	
	Datenbank datenbank = new Datenbank();
	JFileChooser chooser = new JFileChooser();
	JLabel marke = new JLabel("Marke");
	JLabel arbeitsspeicher = new JLabel("Arbeitsspeicher");
	JLabel prozessor = new JLabel("Prozessor");
	JLabel speicherplatz = new JLabel("Speicherplatz");
	JLabel preis = new JLabel("Preis(EUR)");
        JLabel labelgebraucht = new JLabel("Gebraucht ?");
	public JTextField textmarke = new JTextField();
	public JTextField textarbeitsspeicher = new JTextField();
	public JTextField textprozessor = new JTextField();
	public JTextField textspeicherplatz = new JTextField();
	public JTextField textpreis = new JTextField();
        public JRadioButton btngebraucht = new JRadioButton();
        
	
	JButton buttonhinzufügen = new JButton(new ImageIcon("icon/inserer.png"));
	JButton buttonändern = new JButton("Speichern");
	JButton buttonreset = new JButton("Reset");
	
	
	
	JLabel labelimage = new JLabel();
	JLabel labelimage2 = new JLabel();
	JLabel labeltext = new JLabel();
	JLabel labeltext2 = new JLabel();
	public LaptopModell lm ;
	public UUID id;
	JPanel panel = new JPanel();
	  
	 public String Marke ;
	 public int  Arbeitsspeicher ;
	 public String Prozessor;
	 public int Speicherplatz;
	 public float Preis;
         public String Bild;
         public Boolean Gebraucht;
	   

	public AenderungSeite(UUID id) {
		super("Änderungseite");
		
	    

		   getContentPane().add(panel);
				this.setSize(900,650);
				this.setLocationRelativeTo(null);
				this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				this.setVisible(true);
		  	    this.setResizable(false); 
				panel.setLayout(null);
		
		
		
			
			    panel.setBackground(Color.LIGHT_GRAY);
			
			
			marke.setBounds(300,75,400,30);
			textmarke.setBounds(450,75,400,30);
			speicherplatz.setBounds(300,150,400,30);
			textspeicherplatz.setBounds(450,150,400,30);
			prozessor.setBounds(300,225,400,30);
			textprozessor.setBounds(450,225,400,30);
			arbeitsspeicher.setBounds(300,300,400,30);
			textarbeitsspeicher.setBounds(450,300,400,30);
			preis.setBounds(300,375,400,30);
			textpreis.setBounds(450,375,400,30);
                        labelgebraucht.setBounds(300, 450, 400, 30);
                      // combogebraucht.setBounds(470, 430, 100, 30);
                        btngebraucht.setBounds(450, 450, 30, 30);
			
			labeltext.setText("Fotoname:");
			labeltext.setBounds(50,50,300,30);
			
			buttonhinzufügen.setBounds(50,100,50,50);
			buttonändern.setBounds(350,500,130,30);
			buttonändern.setBackground(Color.GREEN);
			buttonändern.setIcon(new ImageIcon("icon/speichern.png"));
			buttonreset.setBounds(550, 500,130, 30);
			buttonreset.setBackground(Color.magenta);
			buttonreset.setIcon(new ImageIcon("icon/reset.png"));
			
			buttonreset.addActionListener((ActionEvent e) -> {
                            if(e.getSource()==buttonreset) {
                                textmarke.setText("");
                                textarbeitsspeicher.setText("");
                                textprozessor.setText("");
                                textspeicherplatz.setText("");
                                textpreis.setText("");
                                labelimage2.setIcon(null);
                                labeltext2.setText("");
                                btngebraucht.setSelected(false);
                                
                            }
                });
			 
			buttonändern.addActionListener((ActionEvent e) -> {
                    if (e.getSource()==buttonändern) {
                        UUID ID = UUID.randomUUID();
                        Marke = textmarke.getText();
                         Speicherplatz =Integer.parseInt(textspeicherplatz.getText());
                        Prozessor = textprozessor.getText();
                         Arbeitsspeicher = Integer.parseInt(textarbeitsspeicher.getText());
                        Preis = Float.parseFloat(textpreis.getText());
                        Bild = bildSource;
                          Gebraucht=btngebraucht.isSelected();
                        //datenbank.addData( ID, Marke,  Arbeitsspeicher, Prozessor,  Speicherplatz,  Preis,  Bild );
                        int buttonändern1 = JOptionPane .showConfirmDialog( AenderungSeite.this,"wollen Sie wirklich diese Daten ändern?","Liebe Administrator",JOptionPane.YES_NO_OPTION);
                        if (buttonändern1 == JOptionPane.YES_OPTION) {
                            Datenbank.updateData(lm.id, Marke, Speicherplatz , Prozessor,Arbeitsspeicher ,  Preis,Bild,Gebraucht);
                            
                            JOptionPane.showMessageDialog( AenderungSeite.this, "Aktualisierung wurde erfolgreich  ","Message",JOptionPane.INFORMATION_MESSAGE);
                            AenderungSeite.this.dispose();
                        } else {
                        }
                    }
                });
			buttonhinzufügen.addActionListener((ActionEvent e) -> {
                    if (e.getSource()==buttonhinzufügen) {
                        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                                "JPG & GIF Images", "jpg", "gif","PNG","png");
                        chooser.setFileFilter(filter);
                        int returnVal = chooser.showOpenDialog(buttonhinzufügen);
                        if (returnVal == JFileChooser.APPROVE_OPTION) {
                            String bildSource1 = chooser.getSelectedFile().getAbsolutePath();
                            String bildName = chooser.getSelectedFile().getName();
                            System.out.println(bildSource1);
                            setImagePath(bildSource1);
                            setImageText(bildName);
                            Path sourceFile = Paths.get(bildSource1);
                            Path targetFile =  Paths.get("icon/");
                            bildSource1 = ("icon/");
                            try {
                                Files.copy(sourceFile, targetFile);
                            } catch (IOException e1) {
                            }
                            labeltext2.setText(bildName);
                            labeltext2.setBounds(120,50,300,30);
                            panel.add(labeltext2);
                            labelimage2.setIcon(new ImageIcon(new ImageIcon(chooser.getSelectedFile().getAbsolutePath() ).getImage().getScaledInstance(200, 200, Image.SCALE_AREA_AVERAGING)));
                            //					    			labelimage2.setBounds(100,150,200,200);
                            panel.add(labelimage2);
                            getRootPane().getContentPane().revalidate();
                            getRootPane().getContentPane().repaint();
                        }
                    }
                });
			
			labelimage2.setBounds(50,200,200,200);
	   panel.add(buttonreset);
	   panel.add(buttonändern);	
	   panel.add(buttonhinzufügen);	
	   panel.add(textmarke);
	   panel.add(textarbeitsspeicher);
	   panel.add(textprozessor);
	   panel.add(textspeicherplatz);
	   panel.add(textpreis);
	   panel.add(labeltext);
	   panel.add(marke);
	   panel.add(arbeitsspeicher);
	   panel.add(prozessor);
	   panel.add(speicherplatz);
	   panel.add(preis);
	   panel.add(labelimage2);
           panel.add(labelgebraucht);
	 //  panel.add(combogebraucht);
           panel.add(btngebraucht);
		
		getDaten(id);
		
					}	
		
	        
	    
				
			
			
	private void getDaten(UUID id) {
	
	
	
		lm = Datenbank.findById(id);
		textmarke.setText(lm.marke);
		labelimage2.setIcon(new ImageIcon(new ImageIcon(lm.bild).getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH)));
		
		textspeicherplatz.setText(Integer.toString(lm.speicherplatz));
		textprozessor.setText(lm.prozessor);
		
		textarbeitsspeicher.setText(Integer.toString(lm.arbeitsspeicher));
		
		
		textpreis.setText(Float.toString(lm.preis));
               btngebraucht.setSelected(lm.gebraucht);
	}
			
			
			
		    
			
		
		
		
		
		
		
					
					
					
				
				public void setImagePath(String path)
				{
					bildSource = path;
				} 
				JLabel getChosenImageText()
				{
					return  labeltext2;
					
				}
				public void setImageText(String name)
				{
					labeltext2.setText(name);

				}	

				
				
    
}

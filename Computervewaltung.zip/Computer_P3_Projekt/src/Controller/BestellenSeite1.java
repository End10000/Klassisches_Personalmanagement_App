/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Database.Datenbank;
import Database.LaptopModell;
import View.NeueComputer;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;

import java.util.UUID;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author nanad
 */
public class BestellenSeite1  extends JFrame{
    BestellInfo bi = new BestellInfo();
    NeueComputer nc = new  NeueComputer();
	Datenbank datenbank = new Datenbank();
//	ÄnderungSeite as = new ÄnderungSeite();
     
	JLabel labelmarke = new JLabel();
	JLabel labelspeicherplatz = new JLabel();
	JLabel labelprozessor = new JLabel();
	
	JLabel labelarbeitsspeicher = new JLabel();
	JLabel labelpreis = new JLabel();
	JLabel labelfoto = new JLabel();
        JLabel labelgebraucht = new JLabel();
	JPanel panel = new JPanel();
	
	JButton btbestellen = new JButton("Bestellen");
	JButton btlöschen = new JButton("Löschen");
	JButton btändern = new JButton("Ändern");
	
	LaptopModell lm ;

	public  UUID id;
	
	public BestellenSeite1(UUID id) {
		
		
   //super("Bestellung");
    this.setTitle("Bestellung");

   getContentPane().add(panel);
		this.setSize(800,600);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setVisible(true);
  	    this.setResizable(false); 
		panel.setLayout(null);
		
		labelmarke.setText("Marke:   " );
		labelmarke.setBounds(400,50,200,30 );
		labelspeicherplatz.setText("Speicherplatz:   " );
		labelspeicherplatz.setBounds(400,100,200,30 );
		labelprozessor.setText("Prozessor:   " );
		labelprozessor.setBounds(400,150,200,30 );
		labelarbeitsspeicher.setText("Arbeitsspeicher: " );
		labelarbeitsspeicher.setBounds(400,200,200,30 );
		labelpreis.setText("Preis:   ");
		labelpreis.setBounds(400,250,200,30 );
                labelgebraucht.setBounds(400,300,200,30);
   // 	labelfoto.setIcon(new ImageIcon(new ImageIcon(sm.bild).getImage().getScaledInstance(100,100, Image.SCALE_SMOOTH)));;
		labelfoto.setBounds(50,75,250,250 );
		

		
	
		
		
	
	
	
	
	

	
	btändern.setBounds(400,400,130,30);
	btändern.setBackground(Color.blue);

	btlöschen.setBounds(200,400,130,30);
	btlöschen.setBackground(Color.MAGENTA);

	btbestellen.setBounds(600,400,130,30);
	btbestellen.setBackground(Color.PINK);
	
	
	btändern.setIcon(new ImageIcon("icon/ändern.png"));
	btlöschen.setIcon(new ImageIcon("icon/löschen.png"));
	btbestellen.setIcon(new ImageIcon("icon/bestellen.png"));
	
	
	btlöschen.addActionListener((ActionEvent e) -> {
       if (e.getSource()==btlöschen) {
           int btlöschen1 = JOptionPane .showConfirmDialog( BestellenSeite1.this,"wollen Sie wirklich dieses Artikel löschen?","Liebe Kunde",JOptionPane.YES_NO_OPTION);
           if (btlöschen1 == JOptionPane.YES_OPTION) {
               Datenbank.deleteData(id);
               
               JOptionPane.showMessageDialog(  BestellenSeite1.this, "Dieser Laptop wurde erfolgreich gelöscht ","Message",JOptionPane.INFORMATION_MESSAGE);
               BestellenSeite1.this.dispose();
           } else {
           }
       }
   });
	 
	
	btbestellen.addActionListener((ActionEvent e) -> {
            if(e.getSource()==btbestellen) {
                createPanelBestellInfo(id);
                
            }
   });
	
	
	btändern.addActionListener((ActionEvent e) -> {
            if(e.getSource()==btändern) {
                AenderungSeite aenderungSeite = new AenderungSeite(id);
                
            }
   });
	panel.add(btändern);
	panel.add(btlöschen);
	panel.add(btbestellen);
	panel.add( labelmarke);
	panel.add(labelspeicherplatz);
	panel.add(labelprozessor);
	panel.add(labelarbeitsspeicher);
	panel.add( labelpreis);
	panel.add( labelfoto);
        panel.add(labelgebraucht);
	
	getDaten(id);
	
		
		
	



	}
	
	

	
	private void getDaten(UUID id)
	{
	
	
		lm = Datenbank.findById(id);
		labelmarke.setText("Marke:  "+" "+ lm.marke);
		labelfoto.setIcon(new ImageIcon(new ImageIcon(lm.bild).getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH)));
		
		labelarbeitsspeicher.setText("Arbeitsspeicher:  "+" "+lm.arbeitsspeicher + "  Go");
		labelprozessor.setText("Prozessor:  "+" "+lm.prozessor);
		
		labelspeicherplatz.setText("Speicherplatz:  "+" "+ lm.speicherplatz+ "  Go");
		
		
		labelpreis.setText("Preis:  "+" "+ lm.preis+ " €");
                if (lm.gebraucht==true){
               // labelgebraucht.setText("Gebraucht?   "+" "+lm.gebraucht);
	labelgebraucht.setText("Gebraucht ?   "+" "+ "ja");
                }else{
                    labelgebraucht.setText("Gebraucht ?:  "+" "+ "Nein");
                
                }
	}
	private JPanel createPanelBestellInfo(UUID id) {
		
		getContentPane().remove(panel);
		
	
		getContentPane().add(bi);
		
	     bi.revalidate();
	     bi.repaint();
		return bi;
		
	

}
	

		
    
}

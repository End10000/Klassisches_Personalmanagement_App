
document.querySelector("form").addEventListener("submit",passwortpruefen);


// prüfe ob die passwort und Username korrekt sind bevor die Anmeldung 

function passwortpruefen(event){
    event.preventDefault(); 

  var usernameInput = document.querySelector("#username").value;
  var passwordInput = document.querySelector("#passwort").value;
   var valid = false;

 if (usernameInput=== "" || passwordInput === "") {
    document.querySelector(".errormessage").innerHTML='Bitte füllen Sie alle Felder aus!';			

}  else{
    document.querySelector(".errormessage").innerHTML='';	
           

}


  if (usernameInput === "donald" && passwordInput ==="web") {
    
    
    document.querySelector("form").reset();

    window.location.href = "HTML/Erste Seite.html"; // Geht zur Erste Seite 
  } 
  if(( usernameInput.length >=1 && passwordInput.length >=1) && !valid) {
    document.querySelector(".errormessage").innerHTML='Etwas stimmt nicht ,Überprüfen Sie bitte ihre Eingabe!';	 // zeige ein Nachricht wenn die Info nicht korrekte sind
       
    
    }
  
  


}
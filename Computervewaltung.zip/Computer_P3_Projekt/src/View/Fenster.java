
package View;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Fenster extends JFrame{
    
    public Fenster(){
    super("Computer Laden");
    
    
    this.setSize(1300, 800);
    this.setBackground( Color.GRAY);
    this.setLocationRelativeTo(null);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    
        /* JPanel conteneur = new JPanel();
        getContentPane().add(conteneur);*/
    
    
    
    LinksSeite LS = new LinksSeite();
    
    this.add(LS,BorderLayout.WEST);
    
    this.add(LS.MB,BorderLayout.CENTER);
    

    
    }
    
    
}

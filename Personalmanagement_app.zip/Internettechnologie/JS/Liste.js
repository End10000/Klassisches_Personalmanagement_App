
    window.addEventListener("load",DatenEmpfangen) ; 
  



   
    var aendern; 
    var loeschen;
    var  image;
    var AktualisierenSeite="Mitarbeiter Aktualisieren.html"

    document.querySelector(".menue").addEventListener("click",newmenu);
    document.querySelector(".close").addEventListener("click",cmenu);
// für  den Bürgerbutton , und ermöglicht die menu2 zu erscheinen
    function newmenu(){

       
       document.querySelector(".box2").classList.toggle("box2content");
     
    }
    function cmenu(){

       
        document.querySelector(".box2").classList.remove("box2content");
      
     }


// nimmt alle Daten von Json -datei und zeige sie an 

   function DatenEmpfangen(){

    fetch('../JSON/Liste.json', {												
        method: 'get',												
        cache: 'no-store'											
})
.then(function(response) {											
    return response.json();											
})
.then(function(mitarbeitern) {



										
for(var i = 0; i<mitarbeitern.length; i++)	{
    
     formular = document.createElement("form");


    feldid = document.createElement("input");
    feldid.setAttribute("type","hidden");
    feldid.setAttribute("name","ID");
    feldid.setAttribute("value",mitarbeitern[i].ID);
   
    
    div = document.createElement('div');
    div.className="mitarbeiter";
    
    image= document.createElement('img');
    image.className="bild";
  

    aendern = document.createElement('button'); 
    aendern.innerHTML = 'Ändern';
    aendern.className = 'btn_aendern';

    loeschen = document.createElement('button'); 
    loeschen.innerHTML = 'Löschen';
    loeschen.className = 'button_loeschen';
    loeschen.setAttribute ("type","submit");
    
    formular.appendChild(loeschen);
    formular.appendChild(feldid);


   

    image.src = mitarbeitern[i].Bild;  

div.innerHTML +=

'ID:'.bold() +" "+ mitarbeitern[i].ID + "<br/>" + 					
'Name:'.bold() +" "+ mitarbeitern[i].Name + "<br/>" + 					
'Vorname:' .bold()  +" "+ mitarbeitern[i].Vorname + "<br/>"  + 					
'Alter:'.bold()  +" "+ mitarbeitern[i].Alter + "<br/>" + 	
'Telefon:'.bold()  +" "+ mitarbeitern[i].Telefon + "<br/>" + 					
'Wohnort:'.bold()  +" "+ mitarbeitern[i].Wohnort +"<br/>" +  
'Email:'.bold()  +" "+ mitarbeitern[i].Email +"<br/>" +                    
'Aufgabe:'.bold()  +" "+ mitarbeitern[i].Aufgabe + "<br/>" ;
    
div.appendChild(image);
div.appendChild(formular);
div.appendChild(aendern);





document.querySelector("#mitarbeitern").appendChild(div);

aendern.addEventListener("click",Update);
formular.addEventListener("submit",MitarbeiterEntfernen);

     
         }

        
})
.catch(function(error) {											
    alert(error);													
});

}

// öffnet eine Seite html für die Aktualisierung
function Update(){
    
    window.location.href = "../HTML/Mitarbeiter Aktualisieren.html";
    
    

}




// verbinden mit Php ,entfernt die Daten von einem Mitarbeiter durch sein Id

async function MitarbeiterEntfernen() {

    event.preventDefault();
    const Eingaben = new FormData(this);
    await fetch ("../PHP/mitarbeiter delete.php",{

        method:"post",
        body:Eingaben
    })

    .then(function(response){
     alert("Diese  Mitarbeiterdaten wurden entfernt");
     location.reload();

    })
    .catch(function(error){
        alert(error);
    
    });	
    document.querySelector("#form-delete").reset();
    // aktualisiert die Seite
  
}








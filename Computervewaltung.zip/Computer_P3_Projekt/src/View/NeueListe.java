
package View;

import Controller.ListSeite;
import Database.Datenbank;
import Database.LaptopModell;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;



import javax.swing.JPanel;
import javax.swing.JScrollPane;


public class NeueListe extends JPanel{
    



    
     public  NeueListe () {
       
   
    
  
    setBackground(Color.white);
    
    List<LaptopModell> data = new ArrayList<>();

			data = Datenbank.findData();
			
			this.showData(data);
		

     
}
   
     
     
     public  void showData(List<LaptopModell> data)
	{	
		
		
		
	
		for(int i=0;i<data.size();i++)
		{
			
                   add(new ListSeite(data.get(i).id,data.get(i).marke, (int) data.get(i).preis,data.get(i).bild,data.get(i).speicherplatz));
            
        
    
        revalidate();
        repaint();
               
		}   
	
	}
}
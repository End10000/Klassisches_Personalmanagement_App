package View;



import Controller.BestellInfo;
import Database.Datenbank;
import java.awt.Color;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.UUID;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;


//import Datenbank.Datenbank;





public class NeueComputer extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String bildSource  ;
	JLabel marke = new JLabel("Marke");
	JLabel speicherplatz = new JLabel("Speicherplatz(Go)");
	JLabel prozessor = new JLabel("Prozessor");
	JLabel arbeitsspeicher = new JLabel("Arbeitsspeicher(Go)");
	JLabel preis = new JLabel("Preis(EUR)");
	public JTextField textmarke = new JTextField();
	public JTextField textspeicherplatz = new JTextField();
	public JTextField textprozessor = new JTextField();
	public JTextField textarbeitsspeicher= new JTextField();
	public JTextField textpreis = new JTextField();
	Datenbank datenbank = new Datenbank();
        
	JButton buttonhinzufügen = new JButton(new ImageIcon("icon/inserer.png"));
	JButton buttonspeichern = new JButton("Speichern");
	JButton buttonneueeintrag = new JButton("Neueeintrag");
        //String [] s1 = {"Ja","Nein"};
	//JComboBox combogebraucht = new JComboBox(s1);
       JRadioButton btngebraucht= new JRadioButton();
	JFileChooser chooser = new JFileChooser();
	JLabel labelgebraucht = new JLabel("Gebraucht ?");
	JLabel labelimage = new JLabel();
        
      
	JLabel labeltext = new JLabel();
	JLabel labeltext2 = new JLabel();
	  UUID ID;
          
	 public String Marke ;
	 public int  Speicherplatz;
	 public String Prozessor;
	 public int Arbeitsspeicher;
	 public float Preis;
	 public String Bild;
         public Boolean Gebraucht;
	 
	 
	public NeueComputer() {
		setLayout(null);
		setBackground(Color.white);
		
		 labelimage.setToolTipText("hier neues Bild hinzufügen");
		marke.setBounds(350,75,400,30);
		textmarke.setBounds(470,75,400,30);
		speicherplatz.setBounds(350,150,400,30);
		textspeicherplatz.setBounds(470,150,400,30);
		prozessor.setBounds(350,225,400,30);
		textprozessor.setBounds(470,225,400,30);
		arbeitsspeicher.setBounds(350,300,400,30);
		textarbeitsspeicher.setBounds(470,300,400,30);
		preis.setBounds(350,375,400,30);
		textpreis.setBounds(470,375,400,30);
		labelgebraucht.setBounds(350, 430, 400, 30);
           //     combogebraucht.setBounds(470, 430, 100, 30);
                btngebraucht.setBounds(470, 430, 30, 30);
                
		labeltext.setText("Fotoname:");
		labeltext.setBounds(50,50,300,30);
		
                
		buttonhinzufügen.setBounds(50,100,50,50);
		buttonspeichern.setBounds(450,500,130,30);
		buttonspeichern.setBackground(Color.blue);
		buttonspeichern.setIcon(new ImageIcon("icon/speichern.png"));
		buttonneueeintrag.setBounds(650, 500,150, 30);
		buttonneueeintrag.setBackground(Color.pink);
		buttonneueeintrag.setIcon(new ImageIcon("icon/reset.png"));
                
           
	
        	buttonneueeintrag.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(e.getSource() ==buttonneueeintrag) {
                            textmarke.setText("");
                            textspeicherplatz.setText("");
                            textprozessor.setText("");
                            textarbeitsspeicher.setText("");
                            textpreis.setText("");
                            labelimage.setIcon(null);
                            labeltext2.setText("");
                            btngebraucht.setSelected(false);
                            
                        }
                    }
                });
		 
		buttonspeichern.addActionListener((ActionEvent e) -> {
                    if (e.getSource()==buttonspeichern) {
                        UUID ID = UUID.randomUUID();
                        Marke = textmarke.getText();
                        Speicherplatz = Integer.parseInt(textspeicherplatz.getText());
                        Prozessor = textprozessor.getText();
                        Arbeitsspeicher =Integer.parseInt(textarbeitsspeicher.getText());
                        Preis = Float.parseFloat(textpreis.getText());
                        Bild = bildSource;
                        Gebraucht=btngebraucht.isSelected();
                        
 
                        
                       if (Bild!= null /*&& Bild != ""*/)
                              
                          {
                        datenbank.addData(ID, Marke, Speicherplatz, Prozessor, Arbeitsspeicher, Preis, Bild,Gebraucht);
                        JOptionPane .showMessageDialog(NeueComputer.this,"Dieser Laptop wurde erfolgreich gespeichert","Nachricht",JOptionPane.INFORMATION_MESSAGE);
                          
                        }else {
                            JOptionPane .showMessageDialog(NeueComputer.this,"Bitte laden Sie ein Bild hoch","Nachricht",JOptionPane.INFORMATION_MESSAGE);
                       
                       
                       }
                        
                    }
                });
		
		buttonhinzufügen.addActionListener((ActionEvent e) -> {
                    if (e.getSource()==buttonhinzufügen) {
                        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                                "JPG & GIF Images", "jpg", "gif","PNG","png");
                        chooser.setFileFilter(filter);
                        int returnVal = chooser.showOpenDialog(buttonhinzufügen);
                        if (returnVal == JFileChooser.APPROVE_OPTION) {
                            String bildSource1 = chooser.getSelectedFile().getAbsolutePath();
                            String bildName = chooser.getSelectedFile().getName();
                            System.out.println(bildSource1);
                            setImagePath(bildSource1);
                            setImageText(bildName);
                            // foto in Datei BASE kopieren
                            Path sourceFile = Paths.get(bildSource1);
                            Path targetFile =  Paths.get("BASE/"+ bildName);
                            bildSource1 = "BASE/"+ bildName;
                            try {
                                Files.copy(sourceFile, targetFile);
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                            labeltext2.setText(bildName);
                            labeltext2.setBounds(120,50,300,30);
                            add(labeltext2);
                            labelimage.setIcon(new ImageIcon(new ImageIcon(chooser.getSelectedFile().getAbsolutePath() ).getImage().getScaledInstance(200, 200, Image.SCALE_AREA_AVERAGING)));
                            labelimage.setBounds(100,150,200,200);
                            add(labelimage);
                            getRootPane().getContentPane().revalidate();
                            getRootPane().getContentPane().repaint();
                        }
                    }
                });
		
		
    add(buttonneueeintrag);
	add(buttonspeichern);	
	add(buttonhinzufügen);	
	add(textmarke);
	add(textspeicherplatz);
	add(textprozessor);
	add(textarbeitsspeicher);
	add(textpreis);
	add(labeltext);
	add(marke);
	add(speicherplatz);
	add(prozessor);
	add(arbeitsspeicher);
	add(preis);
        add(labelgebraucht);
	//add(combogebraucht);
        add(btngebraucht);

        
        

	    
		}
	public void setImagePath(String path)
	{
		bildSource = path;
	}
	
	public JLabel getChosenImageText()
	{
		return  labeltext2;
		
	}
	public void setImageText(String name)
	{
		labeltext2.setText(name);

	}	
}
	
		

	
